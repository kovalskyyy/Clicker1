package com.example.myapplication4;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.CompoundButton;


public class MainActivity extends AppCompatActivity {

    private Button increaseButton;
    private Button resetButton;
    private Switch modeSwitch;
    private TextView counterText;
    private int counter = 0;
    private boolean isPositiveMode = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        increaseButton = findViewById(R.id.increaseButton);
        resetButton = findViewById(R.id.resetButton);
        modeSwitch = findViewById(R.id.modeSwitch);
        counterText = findViewById(R.id.counterText);

        // Obsługa kliknięcia na przycisk zwiększający licznik
        increaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isPositiveMode) {
                    counter++;
                } else {
                    counter--;
                }
                updateCounterText();
            }
        });

        // Obsługa kliknięcia na przycisk resetujący licznik
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counter = 0;
                updateCounterText();
            }
        });

        // Obsługa zmiany stanu przełącznika
        modeSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                isPositiveMode = isChecked;
            }
        });
    }

    // Metoda do aktualizacji tekstu na TextView z licznikiem
    private void updateCounterText() {
        counterText.setText("Licznik: " + counter);
    }

}